<?php
/**
 * Galicianlanguage file
 *
 * @author Medúlio <medulio@ciberirmandade.org>
 */
$lang['menu']                  = 'Xestor de Reversión';
$lang['filter']                = 'Procurar páxinas con correo-lixo';
$lang['revert']                = 'Revertir as páxinas seleccionadas';
$lang['reverted']              = '%s revertido á revisión %s';
$lang['removed']               = '%s eliminado';
$lang['revstart']              = 'Proceso de reversión iniciado. Isto podería demorar un anaco longo. Se o script fallar por superar o seu límite de tempo denantes de rematar, terás que facer a reversión en anacos máis pequenos.';
$lang['revstop']               = 'O proceso de reversión rematou correctamente.';
$lang['note1']                 = 'Nota: esta procura distingue entre maiúsculas e minúsculas';
$lang['note2']                 = 'Nota: a páxina revertirase á última versión que non conteña o termo de correo-lixo <i>%s</i> indicado.';
