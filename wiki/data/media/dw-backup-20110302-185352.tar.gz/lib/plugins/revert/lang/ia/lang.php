<?php
/**
 * Interlingua language file
 *
 * @author robocap <robocap1@gmail.com>
 * @author Martijn Dekker <martijn@inlv.org>
 */
$lang['menu']                  = 'Gestion de reversiones';
$lang['filter']                = 'Cercar paginas spammose';
$lang['revert']                = 'Reverter le paginas seligite';
$lang['reverted']              = '%s revertite al version %s';
$lang['removed']               = '%s removite';
$lang['revstart']              = 'Le processo de reversion ha comenciate. Isto pote durar multo. Si le script expira ante de finir, tu debe divider le reversiones in blocos minor.';
$lang['revstop']               = 'Le processo de reversion ha succedite.';
$lang['note1']                 = 'Nota: iste recerca distingue inter majusculas e minusculas.';
$lang['note2']                 = 'Nota: le pagina essera revertite al ultime version que non contine le termino de spam specificate, <i>%s</i>.';
