<?php
/**
 * Nepali language file
 *
 * @author Saroj Kumar Dhakal <lotusnagarkot@gmail.com>
 * @author SarojKumar Dhakal <lotusnagarkot@yahoo.com>
 * @author Saroj Dhakal<lotusnagarkot@yahoo.com>
 */
$lang['menu']                  = 'पूर्वस्थिती व्यवस्थापक';
$lang['filter']                = 'स्प्यामयुक्त पृष्ठहरु खोज्नुहोस् ';
$lang['revert']                = 'छानिएक पृष्ठहरुलाई पूर्वस्थितिमा फर्काउनुहोस् ।';
$lang['reverted']              = '%s लाई  %s संस्करणमा फर्काइयो ।';
$lang['removed']               = '%s लाई हटाइयो ।';
$lang['revstart']              = 'पूर्वस्थितिमा फर्काउने कार्य सुरु भयो । यसले लामो समय लिन सक्छ। यदि स्क्रिप्टको समय का्र्य सकिनु पूर्व सकियो भने । तपाईले सानो सानो टुक्रा लिएर पुर्वरुपमा फर्काउनु पर्ने हुन्छ ।';
$lang['revstop']               = 'पूर्वस्थितिमा फर्काउने कार्य सफलतापूर्वक सकियो ।';
$lang['note1']                 = 'नोट: यो खोज वर्ण सम्वेदनशील छ';
