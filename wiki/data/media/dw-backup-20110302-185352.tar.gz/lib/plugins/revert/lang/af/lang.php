<?php
/**
 * Afrikaans language file
 *
 */
