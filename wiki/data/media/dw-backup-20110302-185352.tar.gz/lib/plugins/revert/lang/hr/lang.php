<?php
/**
 * Croatian language file
 *
 * @author Branko Rihtman <theney@gmail.com>
 * @author Dražen Odobašić <dodobasic@gmail.com>
 */
