<?php
/**
 * Options for the Page Redirect plugin
 */

$conf['show_note'] = 1; // Display a note about having been redirected on the new page.
 
