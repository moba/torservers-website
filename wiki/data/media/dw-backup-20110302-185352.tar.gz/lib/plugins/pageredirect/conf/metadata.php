<?php
 /**
  * Metadata for configuration manager plugin
  * Additions for the Page Redirect plugin
  *
  * @author    David Lorentsen <zyberdog@quakenet.org>
  */
  
$meta['show_note'] = array('onoff');
  
