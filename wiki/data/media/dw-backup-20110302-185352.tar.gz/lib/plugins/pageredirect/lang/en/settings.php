<?php
/**
 * English language for Page Redirect plugin
 *
 * @license:    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author:     David Lorentsen <zyberdog@quakenet.org>
 */

$lang['show_note'] = 'Display note on page you are redirected to?';
 