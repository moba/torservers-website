<?php
/**
 * English language for Page Redirect plugin
 *
 * @license:    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author:     David Lorentsen <zyberdog@quakenet.org>
 */

$lang['redirect_to']     = "This page has been moved, the new location is %s.";
$lang['redirected_from'] = "You were redirected here from %s.";
