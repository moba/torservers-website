<?php
/**
 * Afrikaans language file
 *
 */
$lang['userewrite']            = 'Gebraik moie URLs';
$lang['sepchar']               = 'Blydsy naam woord spassie';
$lang['typography_o_0']        = 'Niks';
$lang['userewrite_o_0']        = 'niks';
$lang['userewrite_o_1']        = '.htaccess';
$lang['deaccent_o_0']          = 'aff';
$lang['gdlib_o_0']             = 'GD Lib nie beskibaar nie';
$lang['rss_type_o_rss']        = 'RSS 0.91';
$lang['rss_type_o_rss1']       = 'RSS 1.0';
$lang['rss_type_o_rss2']       = 'RSS 2.0';
$lang['rss_type_o_atom']       = 'Atom 0.3';
$lang['rss_type_o_atom1']      = 'Atom 1.0';
$lang['compression_o_0']       = 'niks';
$lang['compression_o_gz']      = 'gzip';
$lang['compression_o_bz2']     = 'bz2';
$lang['xsendfile_o_0']         = 'moet nie gebrake nie';
$lang['useheading_o_0']        = 'Noit';
$lang['useheading_o_1']        = 'Altyde';
