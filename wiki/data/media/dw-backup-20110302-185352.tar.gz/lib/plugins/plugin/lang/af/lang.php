<?php
/**
 * Afrikaans language file
 *
 */
$lang['btn_download']          = 'Af laai';
$lang['btn_enable']            = 'Store';
$lang['url']                   = 'URL';
$lang['unknown']               = 'unbekende';
$lang['name']                  = 'Naam:';
$lang['date']                  = 'Datum:';
$lang['type']                  = 'Tipe:';
$lang['www']                   = 'Web-werf:';
