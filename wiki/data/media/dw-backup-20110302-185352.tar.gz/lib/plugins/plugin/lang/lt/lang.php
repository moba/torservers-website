<?php
/**
 * Lithuanian language file
 *
 * @author audrius.klevas@gmail.com
 * @author Arunas Vaitekunas <aras@fan.lt>
 */
$lang['name']                  = 'Vardas:';
$lang['date']                  = 'Data:';
$lang['type']                  = 'Tipas:';
$lang['desc']                  = 'Aprašas:';
$lang['author']                = 'Autorius:';
$lang['www']                   = 'Tinklapis:';
