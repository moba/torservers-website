<?php
/**
 * Hindi language file
 *
 * @author Abhinav Tyagi <abhinavtyagi11@gmail.com>
 * @author yndesai@gmail.com
 */
$lang['unknown']               = 'अज्ञात';
$lang['deleted']               = 'मिटाया हुआ';
$lang['date']                  = 'दिनांक:';
$lang['author']                = 'लेखक:';
$lang['error']                 = 'अज्ञात त्रुटि हुइ';
