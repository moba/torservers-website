<?php
/**
 * Default configuration for DokuWiki plugin snippets
 */
$conf['highlight_skin'] = 'idea';

// vim:ts=4:sw=4:et:enc=utf-8:
