<?php
/**
 * Configuration metadata for DokuWiki Plugin snippets
 */
$meta['highlight_skin'] = array('string');

// vim:ts=4:sw=4:et:enc=utf-8:
