<?php
/**
 * English language file for DokuWiki Plugin highlightjs
 */
$lang['highlight_skin'] = 'Syntax Highlighter CSS to load (default, dark, far, idea, sunburst, zenburn, vs, ascetic, magula, github, brown_paper, school_book, ir_black)';

