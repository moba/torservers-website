<?php
/**
 * English language file for DokuWiki plugin highlightjs
 */

$lang['toolbar_code']   = 'Insert Code';

// vim:ts=4:sw=4:et:enc=utf-8:
