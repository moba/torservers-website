<?php
/**
 * Korean language file
 *
 * @author jk lee
 * @author dongnak@gmail.com
 * @author Song Younghwan <purluno@gmail.com>
 * @author SONG Younghwan <purluno@gmail.com>
 */
$lang['name']                  = '인기도 조사 (불러오는데 시간이 걸릴 수 있습니다.)';
$lang['submit']                = '자료 보내기';
