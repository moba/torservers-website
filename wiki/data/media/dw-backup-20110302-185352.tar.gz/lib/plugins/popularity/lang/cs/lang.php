<?php
/**
 * Czech language file
 *
 * @author Bohumir Zamecnik <bohumir@zamecnik.org>
 * @author tomas@valenta.cz
 * @author Marek Sacha <sachamar@fel.cvut.cz>
 * @author Lefty <lefty@multihost.cz>
 */
$lang['name']                  = 'Průzkum používání (může chviličku trvat, než se natáhne)';
$lang['submit']                = 'Odeslat data';
