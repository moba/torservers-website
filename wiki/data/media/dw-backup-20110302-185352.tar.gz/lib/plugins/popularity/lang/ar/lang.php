<?php
/**
 * Arabic language file
 *
 * @author Yaman Hokan <always.smile.yh@hotmail.com>
 * @author Usama Akkad <uahello@gmail.com>
 */
$lang['name']                  = 'رد الشعبية (قد يأخذ بعض الوقت ليحمل)';
$lang['submit']                = 'أرسل البيانات';
