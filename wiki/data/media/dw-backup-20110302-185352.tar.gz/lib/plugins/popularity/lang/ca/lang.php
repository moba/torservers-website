<?php
/**
 * Catalan language file
 *
 * @author Carles Bellver <carles.bellver@cent.uji.es>
 * @author Carles Bellver <carles.bellver@gmail.com>
 * @author carles.bellver@cent.uji.es
 */
$lang['name']                  = 'Retroacció sobre popularitat (pot trigar una mica a carregar)';
$lang['submit']                = 'Envia dades';
