<?php
/**
 * Icelandic language file
 *
 * @author Hrannar Baldursson <hrannar.baldursson@gmail.com>
 * @author Ólafur Gunnlaugsson <oli@audiotools.com>
 * @author Erik Bjørn Pedersen <erik.pedersen@shaw.ca>
 */
$lang['submit']                = 'Senda gögn';
