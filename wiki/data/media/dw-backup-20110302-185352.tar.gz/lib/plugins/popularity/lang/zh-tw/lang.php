<?php
/**
 * Chinese Traditional language file
 *
 * @author Li-Jiun Huang <ljhuang.tw@gmail.com>
 * @author http://www.chinese-tools.com/tools/converter-simptrad.html
 * @author Wayne San <waynesan@zerozone.tw>
 * @author Li-Jiun Huang <ljhuang.tw@gmai.com>
 * @author Cheng-Wei Chien <e.cwchien@gmail.com>
 */
$lang['name']                  = '人氣反饋（載入可能需要一些時間）';
$lang['submit']                = '發送數據';
