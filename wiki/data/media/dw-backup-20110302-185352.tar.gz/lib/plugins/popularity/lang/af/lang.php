<?php
/**
 * Afrikaans language file
 *
 */
$lang['submit']                = 'Stuir Data';
