<?php
/**
 * French language file
 *
 * @author gb@isis.u-strasbg.fr
 * @author Guy Brand <gb@isis.u-strasbg.fr>
 * @author stephane.gully@gmail.com
 * @author Guillaume Turri <guillaume.turri@gmail.com>
 * @author Erik Pedersen <erik.pedersen@shaw.ca>
 * @author olivier duperray <duperray.olivier@laposte.net>
 * @author Vincent Feltz <psycho@feltzv.fr>
 * @author Philippe Bajoit <philippe.bajoit@gmail.com>
 * @author Florian Gaub <floriang@floriang.net>
 * @author Samuel Dorsaz samuel.dorsaz@novelion.net
 */
$lang['name']                  = 'Enquête de popularité (peut nécessiter un certain temps pour être chargé)';
$lang['submit']                = 'Envoyer les données';
