<?php
/**
 * Esperanto language file
 *
 * @author Felipo Kastro <fefcas@gmail.com>
 * @author Felipe Castro <fefcas@gmail.com>
 * @author Robert Bogenschneider <robog@gmx.de>
 * @author Erik Pedersen <erik pedersen@shaw.ca>
 * @author Erik Pedersen <erik.pedersen@shaw.ca>
 * @author Robert Bogenschneider <robog@GMX.de>
 * @author Robert BOGENSCHNEIDER <robog@gmx.de>
 */
$lang['name']                  = 'Populareca enketo (eble la ŝargo prokrastos iomete)';
$lang['submit']                = 'Sendi datenaron';
