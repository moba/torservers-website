<?php
/**
 * Finnish language file
 *
 * @author Otto Vainio <otto@valjakko.net>
 * @author Teemu Mattila <ghcsystems@gmail.com>
 */
$lang['name']                  = 'Suosion palaute (voi kestää jonkun aikaa latautua)';
$lang['submit']                = 'Lähetä tiedot';
