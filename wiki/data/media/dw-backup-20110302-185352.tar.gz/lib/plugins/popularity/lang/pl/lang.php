<?php
/**
 * Polish language file
 *
 * @author Grzegorz Żur <grzegorz.zur@gmail.com>
 * @author Mariusz Kujawski <marinespl@gmail.com>
 * @author Maciej Kurczewski <pipijajko@gmail.com>
 * @author Sławomir Boczek <slawkens@gmail.com>
 * @author sleshek@wp.pl
 * @author Leszek Stachowski <shazarre@gmail.com>
 * @author maros <dobrimaros@yahoo.pl>
 * @author Grzegorz Widła <dzesdzes@gmail.com>
 */
$lang['name']                  = 'Informacja o popularności (ładowanie może zająć dłuższą chwilę)';
$lang['submit']                = 'Wyślij dane';
