<?php
/**
 * Slovenian language file
 *
 * @author Dejan Levec <webphp@gmail.com>
 * @author Boštjan Seničar <senicar@gmail.com>
 */
$lang['submit']                = 'Pošlji';
