<?php
/**
 * Italian language file
 *
 * @author Diego Pierotto ita.translations@tiscali.it
 * @author ita.translations@tiscali.it
 * @author Lorenzo Breda <lbreda@gmail.com>
 * @author snarchio@alice.it
 * @author robocap <robocap1@gmail.com>
 * @author Osman Tekin osman.tekin93@hotmail.it
 */
$lang['name']                  = 'Raccolta dati sul wiki (può impiegare del tempo per caricarsi)';
$lang['submit']                = 'Invia dati';
