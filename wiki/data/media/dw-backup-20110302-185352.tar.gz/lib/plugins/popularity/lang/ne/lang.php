<?php
/**
 * Nepali language file
 *
 * @author Saroj Kumar Dhakal <lotusnagarkot@gmail.com>
 * @author SarojKumar Dhakal <lotusnagarkot@yahoo.com>
 * @author Saroj Dhakal<lotusnagarkot@yahoo.com>
 */
$lang['submit']                = 'सामग्री पठाउनुहोस् ';
