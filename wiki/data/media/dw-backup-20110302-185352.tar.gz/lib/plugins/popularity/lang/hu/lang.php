<?php
/**
 * Hungarian language file
 *
 * @author Sandor TIHANYI <stihanyi+dw@gmail.com>
 * @author Siaynoq Mage <siaynoqmage@gmail.com>
 * @author schilling.janos@gmail.com
 * @author Szabó Dávid (szabo.david@gyumolcstarhely.hu)
 * @author Szabó Dávid <szabo.david@gyumolcstarhely.hu>
 */
$lang['name']                  = 'Visszajelzés a DokuWiki használatáról (sok időt vehet igénybe a betöltése)';
$lang['submit']                = 'Adatok elküldése';
