<?php

$lang['name'] = 'Popularity Feedback (may take some time to load)';
$lang['submit'] = 'Send Data';
