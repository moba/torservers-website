<?php
/**
 * Bulgarian language file
 *
 * @author Viktor Usunov <usun0v@mail.bg>
 */
$lang['name']                  = 'Обратна връзка за популярност (може да отнеме известно време за зареждане)';
$lang['submit']                = 'Прати данните';
