<?php
/**
 * Latvian, Lettish language file
 *
 * @author Aivars Miška <allefm@gmail.com>
 */
$lang['name']                  = 'Popularitātes atsauksmes (ielāde var aizņemt kādu laiku)';
$lang['submit']                = 'Nosūtīt datus';
