<?php
/**
 * Slovak language file
 *
 * @author Michal Mesko <michal.mesko@gmail.com>
 * @author exusik@gmail.com
 * @author Martin Michalek <michalek.dev@gmail.com>
 */
$lang['name']                  = 'Prieskum používania (môže chvíľu trvať)';
$lang['submit']                = 'Poslať dáta';
