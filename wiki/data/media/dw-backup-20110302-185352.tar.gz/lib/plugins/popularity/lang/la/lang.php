<?php
/**
 * Latin language file
 *
 */
$lang['name']                  = 'Index fauoris popularis (multum tempus quaerere potest)';
$lang['submit']                = 'Missum die';
