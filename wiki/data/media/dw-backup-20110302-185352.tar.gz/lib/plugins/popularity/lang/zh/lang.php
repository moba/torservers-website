<?php
/**
 * Chinese language file
 *
 * @author ZDYX <zhangduyixiong@gmail.com>
 * @author http://www.chinese-tools.com/tools/converter-tradsimp.html
 * @author George Sheraton guxd@163.com
 * @author Simon zhan <simonzhan@21cn.com>
 * @author mr.jinyi@gmail.com
 * @author ben <ben@livetom.com>
 * @author lainme <lainme993@gmail.com>
 * @author caii <zhoucaiqi@gmail.com>
 */
$lang['name']                  = '人气反馈（载入可能需要一些时间）';
$lang['submit']                = '发送数据';
