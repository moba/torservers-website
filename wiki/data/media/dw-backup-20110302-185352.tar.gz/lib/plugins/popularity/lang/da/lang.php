<?php
/**
 * Danish language file
 *
 * @author Kalle Sommer Nielsen <kalle@php.net>
 * @author Esben Laursen <hyber@hyber.dk>
 * @author Harith <haj@berlingske.dk>
 * @author Daniel Ejsing-Duun <dokuwiki@zilvador.dk>
 * @author Erik Bjørn Pedersen <erik.pedersen@shaw.ca>
 * @author rasmus@kinnerup.com
 * @author Michael Pedersen subben@gmail.com
 */
$lang['name']                  = 'Tilbagemelding om popularitet (vil måske tage en del tid at indlæse)';
$lang['submit']                = 'Send data';
