<?php
/**
 * Lithuanian language file
 *
 * @author audrius.klevas@gmail.com
 * @author Arunas Vaitekunas <aras@fan.lt>
 */
$lang['name']                  = 'Populiarumo apklausa (gali užtrukti pakrovimas)';
$lang['submit']                = 'Pateikti';
