<?php
/**
 * Portuguese language file
 *
 * @author Enrico Nicoletto <liverig@gmail.com>
 * @author Fil <fil@meteopt.com>
 * @author André Neves <drakferion@gmail.com>
 */
$lang['name']                  = 'Retorno (feedback) de Popularidade (pode levar algum tempo a carregar)';
$lang['submit']                = 'Enviar Dados';
