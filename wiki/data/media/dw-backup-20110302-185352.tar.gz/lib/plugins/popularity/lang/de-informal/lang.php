<?php
/**
 * German (informal) language file
 *
 * @author Alexander Fischer <tbanus@os-forge.net>
 * @author Juergen Schwarzer <jschwarzer@freenet.de>
 * @author Marcel Metz <marcel_metz@gmx.de>
 * @author Matthias Schulte <post@lupo49.de>
 */
$lang['name']                  = 'Popularitätsrückmeldung (kann eine Weile dauern, bis es fertig geladen wurde)';
$lang['submit']                = 'Sende Daten';
