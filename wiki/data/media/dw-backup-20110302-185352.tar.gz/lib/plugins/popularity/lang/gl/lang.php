<?php
/**
 * Galician language file
 *
 * @author Medúlio <medulio@ciberirmandade.org>
 */
$lang['name']                  = 'Resposta de Popularidade (pode demorar un tempo a cargar)';
$lang['submit']                = 'Enviar Datos';
