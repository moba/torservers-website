<?php
/**
 * Romanian language file
 *
 * @author Emanuel-Emeric Andrasi <n30@mandrivausers.ro>
 * @author Emanuel-Emeric Andrași <n30@mandrivausers.ro>
 * @author Emanuel-Emeric Andraşi <em.andrasi@mandrivausers.ro>
 * @author Emanuel-Emeric Andrasi <em.andrasi@mandrivausers.ro>
 */
$lang['name']                  = 'Feedback de popularitate (încărcarea poate dura mai mult)';
$lang['submit']                = 'Trimite datele';
