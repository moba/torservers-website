<?php
/**
 * Greek language file
 *
 * @author Konstantinos Koryllos <koryllos@gmail.com>
 * @author George Petsagourakis <petsagouris@gmail.com>
 */
$lang['name']                  = 'Αναφορά Δημοτικότητας (ίσως αργήσει λίγο να εμφανιστεί)';
$lang['submit']                = 'Αποστολή Δεδομένων';
