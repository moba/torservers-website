<?php
/**
 * Japanese language file
 *
 * @author Ikuo Obataya <i.obataya@gmail.com>
 * @author Daniel Dupriest <kououken@gmail.com>
 * @author Kazutaka Miyasaka <kazmiya@gmail.com>
 * @author Yuji Takenaka <webmaster@davilin.com>
 */
$lang['name']                  = '利用状況調査（ロードに少し時間が掛かります）';
$lang['submit']                = 'データ送信';
