<?php
/**
 * Marathi language file
 *
 * @author ghatothkach@hotmail.com
 * @author Padmanabh Kulkarni <kulkarnipadmanabh@gmail.com>
 * @author Padmanabh Kulkarni<kulkarnipadmanabh@gmail.com>
 * @author shantanoo@gmail.com
 */
$lang['name']                  = 'लोकप्रियता फीडबॅक ( लोड होण्यास थोडा वेळ लागेल )';
$lang['submit']                = 'माहीती पाठवा';
