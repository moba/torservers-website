<?php
/**
 * Ukrainian language file
 *
 * @author serg_stetsuk@ukr.net
 * @author okunia@gmail.com
 * @author Oleksandr Kunytsia <okunia@gmail.com>
 * @author Uko uko@uar.net
 * @author Ulrikhe Lukoie  <lukoie@gmail>.com
 */
$lang['name']                  = 'Відгук популярності (може зайняти деякий час)';
$lang['submit']                = 'Передати дані';
