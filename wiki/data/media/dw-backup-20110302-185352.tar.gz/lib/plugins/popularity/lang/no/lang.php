<?php
/**
 * Norwegian language file
 *
 * @author Rune M. Andersen <rune.andersen@gmail.com>
 * @author Jakob Vad Nielsen (me@jakobnielsen.net)
 * @author Kjell Tore Næsgaard  <kjell.t.nasgaard@ntnu.no>
 * @author Knut Staring <knutst@gmail.com>
 * @author Lisa Ditlefsen <lisa@vervesearch.com>
 * @author Erik Pedersen <erik.pedersen@shaw.ca>
 * @author Erik Bjørn Pedersen <erik.pedersen@shaw.ca>
 */
$lang['name']                  = 'Popularitetsfeedback (kan ta litt tid å laste)';
$lang['submit']                = 'Send data';
