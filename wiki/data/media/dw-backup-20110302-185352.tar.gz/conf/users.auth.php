# users.auth.php
# <?php exit()?>
# Don't modify the lines above
#
# Userfile
#
# Format:
#
# user:MD5password:Real Name:email:groups,comma,seperated


moritz:0c5c0637f44fa84226081b918a46040a:Moritz Bartl:moritz@torservers.net:admin,user
juris:$1$95c6ff23$DvAjtPD4NtzPvIenO9od61:juris:juris@torservers.net:user
fontaine:$1$2f34548a$pJPQ2oPZeYGoQxqbfab7A.:Griffin Boyce:griffinboyce@gmail.com:user
tagnaq:$1$89641b48$VBY/7vykeoUJY7.piYsla.:tagnaq:tagnaq@gmail.com:user
